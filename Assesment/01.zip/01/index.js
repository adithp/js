let array = () => {
    let first = ["a","b","c"];
    let second = ["d","e","f"];
    let full = first.concat(second);
    console.log(full.reverse());
}
array();