
const hi = new Date();
let month = hi.getMonth();

switch(month) {
    case 0:
         console.log("Januvary");
         break;
    case 1: 
        console.log("Februvary");
        break;
    case 2:
        console.log("March");
        break;
    case 3:
        console.log("April");
        break;
    case 4:
        onsole.log("May");
        break;
    case 5:
        console.log("June");
        break;
    case 6:
        console.log("July");
        break;
    case 7:
        console.log("Augest");
        break;
    case 8:
        console.log("September");
        break;
    case 9:
        console.log("October");
        break;
    case 10:
        console.log("November");
        break;
    case 11:
        console.log("DEcember");
        break;
    default:
        console.log("Month Incoreect");  
}