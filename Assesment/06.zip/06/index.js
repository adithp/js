
document.addEventListener("keypress",(event) => {
    if(event.code=="KeyE") {
        console.log("You Clicked EQUAL")
    }
    else if (event.code=="KeyQ") {
        console.log("You Clicked EQUAL")
    }
    else if (event.code=="KeyU") {
        console.log("You Clicked EQUAL")
    }
    else if (event.code=="KeyA") {
        console.log("You Clicked EQUAL")
    }
    else if (event.code=="KeyL") {
        console.log("You Clicked EQUAL")
    }
    else {
        console.log("not equal")
    }
})